/*
    1. Takes user input from each player as an int
    2. Compares the two inputs and returns an int to represent winner of the round
    3. Returns -1 if it is a tie
*/

#include <iostream>
#include "Fighter.h"
#include "Player.h"
#include "Ground.h"
using namespace std;

int evaluateRound(int playerOneMove, int playerTwoMove){
    int winner = -1;

    return winner;
}