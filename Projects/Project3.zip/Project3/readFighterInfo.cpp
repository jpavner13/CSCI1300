/*
    1. Takes a string fileName as an input and an array of Fighters
    2. Opens file
    3. Reads each line and creates a fighter object based on that line
    4. Pushes Fighter to list of fighters
    5. Returns -1 if file coulnt be opened
*/

    #include <iostream>
    #include "Fighter.h"
    using namespace std;

    int readFighterInfo(string fileName, Fighter fighters[]){
        
    }
    