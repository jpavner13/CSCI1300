/*
    1. Takes an int to represent line to be read, and an arr of players
    2. Open file
    3. Reads that line and splits it at ','
    4. Creates a new player object
    5. Creates Fighter objects
    6. Pushes fighter to arr of players
    7. Returns -1 if file couldnt be opened
*/

#include <iostream>
#include "Player.h"
using namespace std;

int readPlayerInfoAt(string fileName, int lineNumber, Player players[]){

}