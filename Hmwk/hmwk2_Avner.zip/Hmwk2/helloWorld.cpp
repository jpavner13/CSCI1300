// CS1300 Spring 2021
// Author: Jack (Pierce) Avner
// Recitation: 117 – Naga Sai Meenakshi Sistla
// Homework 2 - Problem #1

#include <iostream>
using namespace std;

int main(){                                     //Initialize main function
    cout << "Hello, World!" << endl;            // Print "Hello, World!"
    return 0;                                   // Return int data type
}