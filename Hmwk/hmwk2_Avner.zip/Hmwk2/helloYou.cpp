// CS1300 Spring 2021
// Author: Jack (Pierce) Avner
// Recitation: 117 – Naga Sai Meenakshi Sistla
// Homework 2 - Problem #2

#include <iostream>
using namespace std;

int main(){                                             //Initialize main function
    string name;                                        //Initialize variable for name
    cout << "Enter your name:" << endl;                 //Print "Enter your name"
    cin >> name;                                        //Set input to name
    cout << "Hello, " << name << "!" << endl;           //Print output
    return 0;                                           //Return data type
}